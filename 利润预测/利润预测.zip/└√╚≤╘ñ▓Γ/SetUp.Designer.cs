﻿namespace 利润预测
{
    partial class SetUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SetUp));
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txt5_2 = new System.Windows.Forms.TextBox();
            this.txt5_1 = new System.Windows.Forms.TextBox();
            this.txt4_2 = new System.Windows.Forms.TextBox();
            this.txt4_1 = new System.Windows.Forms.TextBox();
            this.txt3_2 = new System.Windows.Forms.TextBox();
            this.txt3_1 = new System.Windows.Forms.TextBox();
            this.txt2_2 = new System.Windows.Forms.TextBox();
            this.txt2_1 = new System.Windows.Forms.TextBox();
            this.txt1_2 = new System.Windows.Forms.TextBox();
            this.txt1_1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.btnChange = new System.Windows.Forms.Button();
            this.txt9 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt8 = new System.Windows.Forms.TextBox();
            this.txt7 = new System.Windows.Forms.TextBox();
            this.txt6 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(244)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Location = new System.Drawing.Point(0, 32);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(260, 32);
            this.panel3.TabIndex = 137;
            // 
            // panel11
            // 
            this.panel11.Location = new System.Drawing.Point(248, 32);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(200, 205);
            this.panel11.TabIndex = 169;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(78, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(124, 26);
            this.label15.TabIndex = 0;
            this.label15.Text = "基  本  参  数";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(153)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(-7, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(296, 32);
            this.panel1.TabIndex = 138;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(153)))), ((int)(((byte)(211)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(235, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 31);
            this.button1.TabIndex = 167;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "参  数  修   改";
            // 
            // txt5_2
            // 
            this.txt5_2.BackColor = System.Drawing.Color.White;
            this.txt5_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt5_2.Font = new System.Drawing.Font("宋体", 14F);
            this.txt5_2.ForeColor = System.Drawing.Color.Black;
            this.txt5_2.Location = new System.Drawing.Point(155, 234);
            this.txt5_2.Name = "txt5_2";
            this.txt5_2.ReadOnly = true;
            this.txt5_2.Size = new System.Drawing.Size(88, 22);
            this.txt5_2.TabIndex = 156;
            this.txt5_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt5_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt5_2_KeyPress);
            // 
            // txt5_1
            // 
            this.txt5_1.BackColor = System.Drawing.Color.White;
            this.txt5_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt5_1.Font = new System.Drawing.Font("宋体", 14F);
            this.txt5_1.ForeColor = System.Drawing.Color.Black;
            this.txt5_1.Location = new System.Drawing.Point(77, 234);
            this.txt5_1.Name = "txt5_1";
            this.txt5_1.ReadOnly = true;
            this.txt5_1.Size = new System.Drawing.Size(63, 22);
            this.txt5_1.TabIndex = 155;
            this.txt5_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt5_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt5_1_KeyPress);
            // 
            // txt4_2
            // 
            this.txt4_2.BackColor = System.Drawing.Color.White;
            this.txt4_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt4_2.Font = new System.Drawing.Font("宋体", 14F);
            this.txt4_2.ForeColor = System.Drawing.Color.Black;
            this.txt4_2.Location = new System.Drawing.Point(155, 202);
            this.txt4_2.Name = "txt4_2";
            this.txt4_2.ReadOnly = true;
            this.txt4_2.Size = new System.Drawing.Size(88, 22);
            this.txt4_2.TabIndex = 154;
            this.txt4_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt4_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt4_2_KeyPress);
            // 
            // txt4_1
            // 
            this.txt4_1.BackColor = System.Drawing.Color.White;
            this.txt4_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt4_1.Font = new System.Drawing.Font("宋体", 14F);
            this.txt4_1.ForeColor = System.Drawing.Color.Black;
            this.txt4_1.Location = new System.Drawing.Point(77, 202);
            this.txt4_1.Name = "txt4_1";
            this.txt4_1.ReadOnly = true;
            this.txt4_1.Size = new System.Drawing.Size(63, 22);
            this.txt4_1.TabIndex = 153;
            this.txt4_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt4_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt4_1_KeyPress);
            // 
            // txt3_2
            // 
            this.txt3_2.BackColor = System.Drawing.Color.White;
            this.txt3_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt3_2.Font = new System.Drawing.Font("宋体", 14F);
            this.txt3_2.ForeColor = System.Drawing.Color.Black;
            this.txt3_2.Location = new System.Drawing.Point(155, 169);
            this.txt3_2.Name = "txt3_2";
            this.txt3_2.ReadOnly = true;
            this.txt3_2.Size = new System.Drawing.Size(88, 22);
            this.txt3_2.TabIndex = 152;
            this.txt3_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt3_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt3_2_KeyPress);
            // 
            // txt3_1
            // 
            this.txt3_1.BackColor = System.Drawing.Color.White;
            this.txt3_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt3_1.Font = new System.Drawing.Font("宋体", 14F);
            this.txt3_1.ForeColor = System.Drawing.Color.Black;
            this.txt3_1.Location = new System.Drawing.Point(77, 169);
            this.txt3_1.Name = "txt3_1";
            this.txt3_1.ReadOnly = true;
            this.txt3_1.Size = new System.Drawing.Size(63, 22);
            this.txt3_1.TabIndex = 151;
            this.txt3_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt3_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt3_1_KeyPress);
            // 
            // txt2_2
            // 
            this.txt2_2.BackColor = System.Drawing.Color.White;
            this.txt2_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt2_2.Font = new System.Drawing.Font("宋体", 14F);
            this.txt2_2.ForeColor = System.Drawing.Color.Black;
            this.txt2_2.Location = new System.Drawing.Point(155, 139);
            this.txt2_2.Name = "txt2_2";
            this.txt2_2.ReadOnly = true;
            this.txt2_2.Size = new System.Drawing.Size(88, 22);
            this.txt2_2.TabIndex = 150;
            this.txt2_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt2_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt2_2_KeyPress);
            // 
            // txt2_1
            // 
            this.txt2_1.BackColor = System.Drawing.Color.White;
            this.txt2_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt2_1.Font = new System.Drawing.Font("宋体", 14F);
            this.txt2_1.ForeColor = System.Drawing.Color.Black;
            this.txt2_1.Location = new System.Drawing.Point(77, 139);
            this.txt2_1.Name = "txt2_1";
            this.txt2_1.ReadOnly = true;
            this.txt2_1.Size = new System.Drawing.Size(63, 22);
            this.txt2_1.TabIndex = 149;
            this.txt2_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt2_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt2_1_KeyPress);
            // 
            // txt1_2
            // 
            this.txt1_2.BackColor = System.Drawing.Color.White;
            this.txt1_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt1_2.Font = new System.Drawing.Font("宋体", 14F);
            this.txt1_2.ForeColor = System.Drawing.Color.Black;
            this.txt1_2.Location = new System.Drawing.Point(155, 105);
            this.txt1_2.Name = "txt1_2";
            this.txt1_2.ReadOnly = true;
            this.txt1_2.Size = new System.Drawing.Size(88, 22);
            this.txt1_2.TabIndex = 148;
            this.txt1_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt1_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt1_2_KeyPress);
            // 
            // txt1_1
            // 
            this.txt1_1.BackColor = System.Drawing.Color.White;
            this.txt1_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt1_1.Font = new System.Drawing.Font("宋体", 14F);
            this.txt1_1.ForeColor = System.Drawing.Color.Black;
            this.txt1_1.Location = new System.Drawing.Point(77, 105);
            this.txt1_1.Name = "txt1_1";
            this.txt1_1.ReadOnly = true;
            this.txt1_1.Size = new System.Drawing.Size(63, 22);
            this.txt1_1.TabIndex = 147;
            this.txt1_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt1_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt1_1_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label14.Font = new System.Drawing.Font("微软雅黑", 13F);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(12, 233);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 24);
            this.label14.TabIndex = 146;
            this.label14.Text = "末 矸";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label13.Font = new System.Drawing.Font("微软雅黑", 13F);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(12, 201);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 24);
            this.label13.TabIndex = 145;
            this.label13.Text = "煤 泥";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label12.Font = new System.Drawing.Font("微软雅黑", 13F);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(12, 168);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 24);
            this.label12.TabIndex = 144;
            this.label12.Text = "原 煤";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label11.Font = new System.Drawing.Font("微软雅黑", 13F);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(12, 138);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 24);
            this.label11.TabIndex = 143;
            this.label11.Text = "块 煤";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label10.Font = new System.Drawing.Font("微软雅黑", 13F);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(12, 104);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 24);
            this.label10.TabIndex = 142;
            this.label10.Text = "精 煤";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(244)))), ((int)(((byte)(0)))));
            this.panel4.Controls.Add(this.label16);
            this.panel4.Location = new System.Drawing.Point(0, 267);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(260, 32);
            this.panel4.TabIndex = 157;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(76, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(124, 26);
            this.label16.TabIndex = 1;
            this.label16.Text = "其  它  参  数";
            // 
            // btnChange
            // 
            this.btnChange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.btnChange.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(109)))), ((int)(((byte)(224)))));
            this.btnChange.FlatAppearance.BorderSize = 0;
            this.btnChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChange.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnChange.ForeColor = System.Drawing.Color.Transparent;
            this.btnChange.Location = new System.Drawing.Point(27, 430);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(202, 33);
            this.btnChange.TabIndex = 158;
            this.btnChange.Text = "修   改   参   数";
            this.btnChange.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnChange.UseVisualStyleBackColor = false;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // txt9
            // 
            this.txt9.BackColor = System.Drawing.Color.White;
            this.txt9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt9.Font = new System.Drawing.Font("宋体", 12F);
            this.txt9.Location = new System.Drawing.Point(109, 398);
            this.txt9.Name = "txt9";
            this.txt9.ReadOnly = true;
            this.txt9.Size = new System.Drawing.Size(134, 19);
            this.txt9.TabIndex = 166;
            this.txt9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt9_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label8.Font = new System.Drawing.Font("微软雅黑", 11.5F);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(9, 338);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 21);
            this.label8.TabIndex = 162;
            this.label8.Text = "税 金 系 数";
            // 
            // txt8
            // 
            this.txt8.BackColor = System.Drawing.Color.White;
            this.txt8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt8.Font = new System.Drawing.Font("宋体", 12F);
            this.txt8.Location = new System.Drawing.Point(109, 369);
            this.txt8.Name = "txt8";
            this.txt8.ReadOnly = true;
            this.txt8.Size = new System.Drawing.Size(134, 19);
            this.txt8.TabIndex = 165;
            this.txt8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt8_KeyPress);
            // 
            // txt7
            // 
            this.txt7.BackColor = System.Drawing.Color.White;
            this.txt7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt7.Font = new System.Drawing.Font("宋体", 12F);
            this.txt7.Location = new System.Drawing.Point(109, 340);
            this.txt7.Name = "txt7";
            this.txt7.ReadOnly = true;
            this.txt7.Size = new System.Drawing.Size(134, 19);
            this.txt7.TabIndex = 164;
            this.txt7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt7_KeyPress);
            // 
            // txt6
            // 
            this.txt6.BackColor = System.Drawing.Color.White;
            this.txt6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt6.Font = new System.Drawing.Font("宋体", 12F);
            this.txt6.Location = new System.Drawing.Point(109, 311);
            this.txt6.Name = "txt6";
            this.txt6.ReadOnly = true;
            this.txt6.Size = new System.Drawing.Size(134, 19);
            this.txt6.TabIndex = 163;
            this.txt6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt6_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label22.Font = new System.Drawing.Font("微软雅黑", 11.5F);
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(8, 367);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 21);
            this.label22.TabIndex = 161;
            this.label22.Text = "月成本系数";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label23.Font = new System.Drawing.Font("微软雅黑", 11.5F);
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(8, 395);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(90, 21);
            this.label23.TabIndex = 160;
            this.label23.Text = "年成本系数";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(0)))));
            this.label24.Font = new System.Drawing.Font("微软雅黑", 11.5F);
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(9, 310);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(89, 21);
            this.label24.TabIndex = 159;
            this.label24.Text = "成 本 基 数";
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(266, 64);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 206);
            this.panel2.TabIndex = 167;
            // 
            // panel6
            // 
            this.panel6.Location = new System.Drawing.Point(246, 299);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 197);
            this.panel6.TabIndex = 168;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(-208, 299);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(216, 197);
            this.panel7.TabIndex = 169;
            // 
            // panel8
            // 
            this.panel8.Location = new System.Drawing.Point(196, 177);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(200, 197);
            this.panel8.TabIndex = 169;
            // 
            // panel9
            // 
            this.panel9.Location = new System.Drawing.Point(-7, 469);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(283, 194);
            this.panel9.TabIndex = 169;
            // 
            // panel12
            // 
            this.panel12.Location = new System.Drawing.Point(246, 64);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(200, 203);
            this.panel12.TabIndex = 169;
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(-187, 64);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 203);
            this.panel5.TabIndex = 170;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12.5F);
            this.label1.Location = new System.Drawing.Point(12, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 23);
            this.label1.TabIndex = 171;
            this.label1.Text = "品  种";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12.5F);
            this.label3.Location = new System.Drawing.Point(78, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 23);
            this.label3.TabIndex = 172;
            this.label3.Text = "售    价";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12.5F);
            this.label4.Location = new System.Drawing.Point(153, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 23);
            this.label4.TabIndex = 173;
            this.label4.Text = "回 收 系 数";
            // 
            // SetUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(259, 478);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.txt9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt8);
            this.Controls.Add(this.txt7);
            this.Controls.Add(this.txt6);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.txt5_2);
            this.Controls.Add(this.txt5_1);
            this.Controls.Add(this.txt4_2);
            this.Controls.Add(this.txt4_1);
            this.Controls.Add(this.txt3_2);
            this.Controls.Add(this.txt3_1);
            this.Controls.Add(this.txt2_2);
            this.Controls.Add(this.txt2_1);
            this.Controls.Add(this.txt1_2);
            this.Controls.Add(this.txt1_1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Name = "SetUp";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SetUp";
            this.Load += new System.EventHandler(this.SetUp_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.SetUp_Paint);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt5_2;
        private System.Windows.Forms.TextBox txt5_1;
        private System.Windows.Forms.TextBox txt4_2;
        private System.Windows.Forms.TextBox txt4_1;
        private System.Windows.Forms.TextBox txt3_2;
        private System.Windows.Forms.TextBox txt3_1;
        private System.Windows.Forms.TextBox txt2_2;
        private System.Windows.Forms.TextBox txt2_1;
        private System.Windows.Forms.TextBox txt1_2;
        private System.Windows.Forms.TextBox txt1_1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.TextBox txt9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt8;
        private System.Windows.Forms.TextBox txt7;
        private System.Windows.Forms.TextBox txt6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;

    }
}